<!DOCTYPE html>
<html <?php language_attributes(); ?> class="scroll-smooth">

<head>
    <meta charset="<?php bloginfo('charset'); ?>" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title><?php wp_title('|', true, 'right'); ?></title>
    <meta name="description"
        content="Premier early learning academy nurturing bright minds – find your nearest KIDazzle center and enroll today." />

    <!-- Google Fonts: Inter and Merriweather/Outfit-like -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Merriweather:ital,wght@0,400;0,700;1,400&family=Outfit:wght@500;700;800&display=swap"
        rel="stylesheet">

    <?php wp_head(); ?>
</head>

<body <?php body_class("antialiased text-brand-dark bg-brand-cream font-sans"); ?>>
    <!-- Skip link -->
    <a href="#main-content"
        class="sr-only focus:not-sr-only focus:absolute focus:top-2 focus:left-2 bg-brand-cyan text-white p-2 rounded z-50">Skip
        to Main Content</a>

    <!-- Header / Navigation -->
    <header class="fixed w-full top-0 z-40 bg-white/95 backdrop-blur-sm shadow-sm transition-all duration-300 transform"
        id="main-header">
        <div class="container mx-auto px-4 md:px-6 py-3 flex items-center justify-between">
            <!-- Logo -->
            <a href="<?php echo home_url(); ?>" class="flex items-center group">
                <!-- Placeholder for Logo - In real app, verify path -->
                <div
                    class="w-10 h-10 bg-brand-yellow rounded-full flex items-center justify-center mr-3 group-hover:scale-110 transition-transform">
                    <span class="text-xl">K</span>
                </div>
                <span class="text-2xl font-display font-extrabold text-brand-blue tracking-tight">KIDazzle</span>
            </a>

            <!-- Desktop Nav -->
            <nav aria-label="Main Navigation" class="hidden lg:flex space-x-8 items-center">
                <a href="#programs"
                    class="text-brand-dark hover:text-brand-cyan font-semibold transition-colors">Programs</a>
                <a href="#curriculum"
                    class="text-brand-dark hover:text-brand-cyan font-semibold transition-colors">Curriculum</a>
                <a href="#locations"
                    class="text-brand-dark hover:text-brand-cyan font-semibold transition-colors">Locations</a>
                <a href="#about" class="text-brand-dark hover:text-brand-cyan font-semibold transition-colors">About</a>
                <a href="#contact" class="btn btn-outline py-2 px-5 text-sm">Contact Support</a>
                <a href="#find-center" class="btn btn-primary py-2 px-5 text-sm shadow-md hover:shadow-xl">Find A
                    Center</a>
            </nav>

            <!-- Mobile Controls -->
            <div class="flex items-center space-x-4 lg:hidden">
                <button class="text-sm font-medium hover:underline text-brand-blue">EN 🇺🇸</button>
                <button id="mobile-menu-btn" class="p-2 text-brand-dark focus:outline-none" aria-label="Open Menu">
                    <svg class="h-8 w-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M4 6h16M4 12h16M4 18h16" />
                    </svg>
                </button>
            </div>
        </div>

        <!-- Mobile Menu (Hidden by default) -->
        <div id="mobile-menu"
            class="hidden absolute top-full left-0 w-full bg-white border-t border-gray-100 shadow-lg lg:hidden">
            <nav class="flex flex-col p-4 space-y-4">
                <a href="#programs" class="text-lg font-medium text-brand-dark hover:text-brand-cyan">Programs</a>
                <a href="#curriculum" class="text-lg font-medium text-brand-dark hover:text-brand-cyan">Curriculum</a>
                <a href="#locations" class="text-lg font-medium text-brand-dark hover:text-brand-cyan">Locations</a>
                <a href="#about" class="text-lg font-medium text-brand-dark hover:text-brand-cyan">About</a>
                <hr class="border-gray-100" />
                <a href="#find-center" class="btn btn-primary text-center">Find a Center</a>
                <a href="#contact" class="btn btn-outline text-center">Contact Support</a>
            </nav>
        </div>
    </header>

    <main id="main-content" class="pt-20"> <!-- pt-20 to offset fixed header -->
        <!-- Hero Section -->
        <section class="relative min-h-[90vh] flex items-center justify-center overflow-hidden">
            <!-- Background Image with Overlay -->
            <div class="absolute inset-0 bg-brand-blue/90">
                <!-- Placeholder for hero image - using a generic high-quality placeholder URL or local asset if available -->
                <!-- In production, we'd use a real optimized image -->
                <img src="https://images.unsplash.com/photo-1587654780291-39c940483713?q=80&w=2070&auto=format&fit=crop"
                    alt="Happy children playing" class="w-full h-full object-cover opacity-20 mix-blend-overlay" />
            </div>

            <!-- Animated Shapes (CSS only for perf) -->
            <div class="absolute top-20 left-10 w-32 h-32 bg-brand-yellow/20 rounded-full blur-3xl animate-float"></div>
            <div class="absolute bottom-20 right-10 w-48 h-48 bg-brand-cyan/20 rounded-full blur-3xl animate-float"
                style="animation-delay: 2s;"></div>

            <!-- Content -->
            <div class="relative container mx-auto px-4 md:px-6 text-center z-10 flex flex-col items-center">
                <div
                    class="inline-block px-4 py-1 mb-6 bg-white/10 backdrop-blur-md rounded-full border border-white/20 animate-fade-in-up">
                    <span class="text-brand-yellow font-bold tracking-wide text-sm uppercase">Now Enrolling for Fall
                        2025</span>
                </div>

                <h1 class="text-5xl md:text-7xl font-display font-extrabold text-white leading-tight mb-6 animate-fade-in-up"
                    style="animation-delay: 0.1s;">
                    Where Learning <br class="hidden md:block" />
                    <span
                        class="text-transparent bg-clip-text bg-gradient-to-r from-brand-yellow via-brand-gold to-brand-cyan drop-shadow-sm">
                        is Fun!</span>
                </h1>

                <p class="text-lg md:text-2xl text-brand-cream/90 max-w-2xl mb-10 animate-fade-in-up font-light"
                    style="animation-delay: 0.2s;">
                    Premier early learning academy nurturing bright minds in a warm, safe, and joyful environment.
                </p>

                <div class="flex flex-col sm:flex-row gap-4 animate-fade-in-up" style="animation-delay: 0.3s;">
                    <a href="#locations"
                        class="btn btn-primary text-lg px-8 py-4 shadow-xl hover:shadow-2xl hover:scale-105 transition-transform">
                        Find Your Center
                    </a>
                    <a href="#programs"
                        class="btn bg-white/10 backdrop-blur-sm text-white border border-white/30 hover:bg-white/20 text-lg px-8 py-4 rounded-full transition-all">
                        Explore Programs
                    </a>
                </div>
            </div>

            <!-- Why Choose Us Section -->
            <section id="why-us" class="py-20 bg-white relative overflow-hidden">
                <!-- Decorative background element -->
                <div
                    class="absolute top-0 left-0 w-64 h-64 bg-brand-gold/5 rounded-full blur-3xl -translate-x-1/2 -translate-y-1/2">
                </div>

                <div class="container mx-auto px-4 md:px-6">
                    <div class="text-center mb-16 max-w-3xl mx-auto">
                        <h2 class="text-3xl md:text-5xl font-display font-bold text-brand-dark mb-6">Why Families Choose
                            KIDazzle
                        </h2>
                        <p class="text-xl text-gray-600">Combining the resources of a premier academy with the personal
                            touch of a
                            family-owned school.</p>
                    </div>

                    <div class="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
                        <!-- Feature 1 -->
                        <div
                            class="group p-8 rounded-3xl bg-brand-cream border border-gray-100 shadow-sm hover:shadow-xl hover:-translate-y-2 transition-all duration-300">
                            <div
                                class="w-16 h-16 mx-auto mb-6 bg-brand-yellow/20 rounded-2xl flex items-center justify-center text-3xl group-hover:scale-110 transition-transform">
                                🍎
                            </div>
                            <h3 class="font-display font-bold text-xl text-brand-dark mb-3 text-center">Healthy Meals
                            </h3>
                            <p class="text-gray-600 text-center leading-relaxed">Chef-prepared, nutritious meals served
                                daily to fuel
                                growing bodies and minds.</p>
                        </div>

                        <!-- Feature 2 -->
                        <div
                            class="group p-8 rounded-3xl bg-brand-cream border border-gray-100 shadow-sm hover:shadow-xl hover:-translate-y-2 transition-all duration-300">
                            <div
                                class="w-16 h-16 mx-auto mb-6 bg-brand-blue/10 rounded-2xl flex items-center justify-center text-3xl group-hover:scale-110 transition-transform">
                                ❤️
                            </div>
                            <h3 class="font-display font-bold text-xl text-brand-dark mb-3 text-center">Family Owned
                            </h3>
                            <p class="text-gray-600 text-center leading-relaxed">31 years of trusted care, treating
                                every child as
                                part of our own family.</p>
                        </div>

                        <!-- Feature 3 -->
                        <div
                            class="group p-8 rounded-3xl bg-brand-cream border border-gray-100 shadow-sm hover:shadow-xl hover:-translate-y-2 transition-all duration-300">
                            <div
                                class="w-16 h-16 mx-auto mb-6 bg-brand-cyan/10 rounded-2xl flex items-center justify-center text-3xl group-hover:scale-110 transition-transform">
                                🎨
                            </div>
                            <h3 class="font-display font-bold text-xl text-brand-dark mb-3 text-center">Creative
                                Curriculum</h3>
                            <p class="text-gray-600 text-center leading-relaxed">Research-based, play-centered learning
                                that adapts to
                                each child's needs.</p>
                        </div>

                        <!-- Feature 4 -->
                        <div
                            class="group p-8 rounded-3xl bg-brand-cream border border-gray-100 shadow-sm hover:shadow-xl hover:-translate-y-2 transition-all duration-300">
                            <div
                                class="w-16 h-16 mx-auto mb-6 bg-brand-gold/10 rounded-2xl flex items-center justify-center text-3xl group-hover:scale-110 transition-transform">
                                🛡️
                            </div>
                            <h3 class="font-display font-bold text-xl text-brand-dark mb-3 text-center">Safety First
                            </h3>
                            <p class="text-gray-600 text-center leading-relaxed">Secure facilities with vigilant
                                supervision and
                                strict safety protocols.</p>
                        </div>
                    </div>
                </div>
            </section>

            <!-- Programs Section -->
            <section id="programs" class="py-20 bg-gray-50">
                <div class="container mx-auto px-4 md:px-6">
                    <div class="text-center mb-16">
                        <span class="text-brand-cyan font-bold tracking-wider uppercase text-sm mb-2 block">Our
                            Academy</span>
                        <h2 class="text-4xl md:text-5xl font-display font-bold text-brand-dark">Programs for Every Age
                        </h2>
                    </div>

                    <div class="grid md:grid-cols-2 gap-10">
                        <!-- Infants & Toddlers -->
                        <div
                            class="bg-white rounded-[2rem] p-8 md:p-12 shadow-md hover:shadow-2xl transition-shadow flex flex-col md:flex-row items-center md:items-start gap-8">
                            <div
                                class="w-full md:w-1/3 aspect-square bg-brand-yellow/20 rounded-2xl flex items-center justify-center text-6xl">
                                👶
                            </div>
                            <div class="flex-1 text-center md:text-left">
                                <h3 class="text-2xl font-bold font-display text-brand-dark mb-4">Infants <span
                                        class="text-base font-sans font-normal text-gray-500 block sm:inline">(6 wks -
                                        12 mos)</span></h3>
                                <p class="text-gray-600 mb-6 font-light leading-relaxed">Nurturing care, tummy time, and
                                    sensory play.
                                    We build trust and security through daily bonding and gentle stimulation.</p>
                                <a href="#contact"
                                    class="text-brand-blue font-bold hover:text-brand-gold hover:underline transition-colors">Learn
                                    More
                                    &rarr;</a>
                            </div>
                        </div>

                        <div
                            class="bg-white rounded-[2rem] p-8 md:p-12 shadow-md hover:shadow-2xl transition-shadow flex flex-col md:flex-row items-center md:items-start gap-8">
                            <div
                                class="w-full md:w-1/3 aspect-square bg-brand-cyan/20 rounded-2xl flex items-center justify-center text-6xl">
                                🧸
                            </div>
                            <div class="flex-1 text-center md:text-left">
                                <h3 class="text-2xl font-bold font-display text-brand-dark mb-4">Toddlers <span
                                        class="text-base font-sans font-normal text-gray-500 block sm:inline">(12 - 24
                                        mos)</span></h3>
                                <p class="text-gray-600 mb-6 font-light leading-relaxed">We focus on gross motor skills,
                                    early language,
                                    and social interaction. Safe spaces for little explorers to move and grow.</p>
                                <a href="#contact"
                                    class="text-brand-blue font-bold hover:text-brand-gold hover:underline transition-colors">Learn
                                    More
                                    &rarr;</a>
                            </div>
                        </div>

                        <!-- Preschool & Pre-K -->
                        <div
                            class="bg-white rounded-[2rem] p-8 md:p-12 shadow-md hover:shadow-2xl transition-shadow flex flex-col md:flex-row items-center md:items-start gap-8">
                            <div
                                class="w-full md:w-1/3 aspect-square bg-brand-blue/10 rounded-2xl flex items-center justify-center text-6xl">
                                ✏️
                            </div>
                            <div class="flex-1 text-center md:text-left">
                                <h3 class="text-2xl font-bold font-display text-brand-dark mb-4">Preschool <span
                                        class="text-base font-sans font-normal text-gray-500 block sm:inline">(2 - 4
                                        years)</span></h3>
                                <p class="text-gray-600 mb-6 font-light leading-relaxed">Building independence and
                                    curiosity. Our
                                    structured play builds the foundation for reading, math, and social cooperation.</p>
                                <a href="#contact"
                                    class="text-brand-blue font-bold hover:text-brand-gold hover:underline transition-colors">Learn
                                    More
                                    &rarr;</a>
                            </div>
                        </div>

                        <div
                            class="bg-white rounded-[2rem] p-8 md:p-12 shadow-md hover:shadow-2xl transition-shadow flex flex-col md:flex-row items-center md:items-start gap-8">
                            <div
                                class="w-full md:w-1/3 aspect-square bg-brand-gold/20 rounded-2xl flex items-center justify-center text-6xl">
                                🎓
                            </div>
                            <div class="flex-1 text-center md:text-left">
                                <h3 class="text-2xl font-bold font-display text-brand-dark mb-4">GA Pre-K <span
                                        class="text-base font-sans font-normal text-gray-500 block sm:inline">(4
                                        years)</span></h3>
                                <p class="text-gray-600 mb-6 font-light leading-relaxed">Kindergarten readiness with
                                    state-approved
                                    curriculum. We ensure every child is confident and ready for school success.</p>
                                <a href="#contact"
                                    class="text-brand-blue font-bold hover:text-brand-gold hover:underline transition-colors">Learn
                                    More
                                    &rarr;</a>
                            </div>
                        </div>
                    </div>

                    <div class="mt-16 text-center">
                        <a href="#contact" class="btn btn-primary text-xl px-10 py-4 shadow-xl">Enroll Your Child
                            Today</a>
                    </div>
                </div>
            </section>

            <!-- Story/Testimonials -->
            <section id="about" class="py-20 bg-brand-blue text-white relative overflow-hidden">
                <!-- Background decoration -->
                <div
                    class="absolute top-0 right-0 w-96 h-96 bg-brand-cyan/20 rounded-full blur-3xl translate-x-1/2 -translate-y-1/2">
                </div>

                <div class="container mx-auto px-4 md:px-6 relative z-10">
                    <div class="md:flex md:items-center md:space-x-16">
                        <div class="md:w-1/2 mb-10 md:mb-0">
                            <span class="text-brand-yellow font-bold tracking-wider uppercase text-sm mb-4 block">Our
                                Story</span>
                            <h2 class="text-4xl md:text-5xl font-display font-bold mb-6">From Our Family to Yours</h2>
                            <p class="text-lg text-blue-100 mb-6 leading-relaxed">
                                KIDazzle began 31 years ago as a single center founded by a passionate teacher and
                                mother. Today, our
                                family has grown, but our core belief remains: every child deserves a loving,
                                stimulating place to grow.
                            </p>
                            <p class="text-xl font-medium text-white">We invite you to join the KIDazzle family, where
                                <span class="text-brand-yellow">learning is love</span>.</p>
                        </div>

                        <div class="md:w-1/2">
                            <div class="bg-white/10 backdrop-blur-md p-10 rounded-3xl border border-white/20 shadow-lg">
                                <div class="text-brand-yellow text-4xl mb-4">★★★★★</div>
                                <blockquote class="text-xl italic font-serif leading-relaxed mb-6">
                                    "The teachers at KIDazzle truly care. My shy little one now comes home every day
                                    excited to tell me
                                    what she learned. Enrolling her was the best decision we made!"
                                </blockquote>
                                <footer class="flex items-center space-x-4">
                                    <div class="w-12 h-12 bg-gray-300 rounded-full overflow-hidden">
                                        <!-- Placeholder avatar -->
                                        <div class="w-full h-full bg-slate-300"></div>
                                    </div>
                                    <div>
                                        <div class="font-bold">Jane D.</div>
                                        <div class="text-sm text-blue-200">KIDazzle Parent</div>
                                    </div>
                                </footer>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <!-- Locations -->
            <section id="locations" class="py-20 bg-white">
                <div class="container mx-auto px-4 md:px-6 text-center">
                    <h2 class="text-4xl font-display font-bold text-brand-dark mb-6">Find a KIDazzle Center</h2>
                    <p class="text-gray-600 text-lg mb-12 max-w-2xl mx-auto">Conveniently located to serve your
                        community. Visit
                        us for a tour!</p>

                    <div class="grid md:grid-cols-3 gap-8">
                        <!-- Location 1 -->
                        <div
                            class="p-8 rounded-3xl border border-gray-100 bg-gray-50 hover:bg-white hover:shadow-xl transition-all duration-300 text-left group">
                            <h3
                                class="text-2xl font-bold text-brand-dark mb-2 group-hover:text-brand-blue transition-colors">
                                Atlanta
                                (West End)</h3>
                            <p class="text-gray-600 mb-4">123 Oak St, Atlanta, GA</p>
                            <div class="flex space-x-4">
                                <a href="tel:4045550100" class="font-bold text-gray-700 hover:text-brand-gold">📞 (404)
                                    555-0100</a>
                            </div>
                            <div class="mt-6 pt-6 border-t border-gray-200 flex justify-between">
                                <a href="#" class="text-brand-cyan font-bold hover:underline">Get Directions</a>
                                <a href="#" class="text-brand-cyan font-bold hover:underline">Details</a>
                            </div>
                        </div>

                        <!-- Location 2 -->
                        <div
                            class="p-8 rounded-3xl border border-gray-100 bg-gray-50 hover:bg-white hover:shadow-xl transition-all duration-300 text-left group">
                            <h3
                                class="text-2xl font-bold text-brand-dark mb-2 group-hover:text-brand-blue transition-colors">
                                College
                                Park</h3>
                            <p class="text-gray-600 mb-4">456 Maple Ave, College Park, GA</p>
                            <div class="flex space-x-4">
                                <a href="tel:7705550199" class="font-bold text-gray-700 hover:text-brand-gold">📞 (770)
                                    555-0199</a>
                            </div>
                            <div class="mt-6 pt-6 border-t border-gray-200 flex justify-between">
                                <a href="#" class="text-brand-cyan font-bold hover:underline">Get Directions</a>
                                <a href="#" class="text-brand-cyan font-bold hover:underline">Details</a>
                            </div>
                        </div>

                        <!-- Location 3 -->
                        <div
                            class="p-8 rounded-3xl border border-gray-100 bg-gray-50 hover:bg-white hover:shadow-xl transition-all duration-300 text-left group">
                            <h3
                                class="text-2xl font-bold text-brand-dark mb-2 group-hover:text-brand-blue transition-colors">
                                Orangeburg</h3>
                            <p class="text-gray-600 mb-4">789 Poplar Rd, Orangeburg, SC</p>
                            <div class="flex space-x-4">
                                <a href="tel:8035550102" class="font-bold text-gray-700 hover:text-brand-gold">📞 (803)
                                    555-0102</a>
                            </div>
                            <div class="mt-6 pt-6 border-t border-gray-200 flex justify-between">
                                <a href="#" class="text-brand-cyan font-bold hover:underline">Get Directions</a>
                                <a href="#" class="text-brand-cyan font-bold hover:underline">Details</a>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <!-- Footer -->
            <footer class="bg-brand-dark text-white py-12 border-t border-gray-800">
                <div class="container mx-auto px-4 md:px-6">
                    <div class="flex flex-col md:flex-row justify-between items-center">
                        <div class="mb-6 md:mb-0 text-center md:text-left">
                            <span class="text-2xl font-display font-extrabold text-white tracking-tight">KIDazzle</span>
                            <p class="text-gray-400 mt-2 text-sm">© 2025 KIDazzle Child Care Inc. All rights reserved.
                            </p>
                        </div>

                        <div class="flex space-x-8 text-sm font-medium text-gray-300">
                            <a href="#" class="hover:text-brand-yellow transition-colors">Privacy Policy</a>
                            <a href="#" class="hover:text-brand-yellow transition-colors">Accessibility</a>
                            <a href="#" class="hover:text-brand-yellow transition-colors">Careers</a>
                            <a href="#contact" class="hover:text-brand-yellow transition-colors">Contact</a>
                        </div>
                    </div>
                </div>
            </footer>

            <?php wp_footer(); ?>
</body>

</html>